import GUIpackage.MainFrame;

public class TextEditor {
    public static void main(String[] args){
        
        //Makes a GUI object of MainFrame, centers on screen, and sets visible
        MainFrame GUI = new MainFrame();
        GUI.setLocationRelativeTo(null);
        GUI.setVisible(true);
        
    }
}
