
public class GuiRunner {
    public static void main(String[] args){
        //Creates a new CalcGUI named gui, centers it on the screen, and makes it visible
        CalcGUI gui = new CalcGUI();
        gui.setLocationRelativeTo(null);
        gui.setVisible(true);
    }
}
